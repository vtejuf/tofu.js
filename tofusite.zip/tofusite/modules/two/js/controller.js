Tofu.ready('two',function(){
	this.container.innerHTML = this.template;
});