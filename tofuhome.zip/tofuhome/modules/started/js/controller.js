Tofu.ready('started',function(){
	this.container.innerHTML = this.template;
});