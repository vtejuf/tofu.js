Tofu.ready('api',function(){
	this.container.innerHTML = this.template;
});