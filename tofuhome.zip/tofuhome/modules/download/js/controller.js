Tofu.ready('download', function(){
	this.container.innerHTML = this.template;
});